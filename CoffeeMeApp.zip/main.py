import tkinter as tk
# Here I created the window resolution and title
window = tk.Tk()
window.title("Coffee Me")
window.geometry("300x300")
# Next I added a greeting for my app
hello = tk.Label(text="Welcome to the Coffee Me ordering app!")
hello.pack()
# I then added instructions for the user
instruction= tk.Label(text= "Please select your coffee below!")
instruction.pack()
# I defined my fuction for the prices of most coffees
def buttonFunction():
  print("The price is $5")
#  I added buttons for each item on the menu and assigned the price to print out when the button is clicked
dark= tk.Button(text="Dark Roast", command = buttonFunction)
dark.pack()

medium= tk.Button(text = "Medium Roast", command = buttonFunction)
medium.pack()

light= tk.Button(text = "Light Roast", command = buttonFunction)
light.pack()
# I created a seperate defining function just for the price difference for the cappuccino
def buttonFunctiontwo():
  print("The price is $8")
cap= tk.Button(text = "Cappuccino", command = buttonFunctiontwo)
cap.pack()

tk.mainloop()