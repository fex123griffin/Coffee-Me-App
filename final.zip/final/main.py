import tkinter as tk
from tkinter import messagebox
from PIL import ImageTk,Image
# Here I created the window resolution and title
window = tk.Tk()
window.iconbitmap('coffee3.ico')
window.title("Coffee Me")
window.geometry("400x800")

#Pictures
coffee_pic = ImageTk.PhotoImage(Image.open("coffee.png"))
pic_lbl = tk.Label(window, image=coffee_pic)
pic_lbl.pack()

# Next I added a greeting for my app
hello = tk.Label(text="Welcome to the Coffee Me ordering app!")
hello.pack()

#Name entry 



my_label = tk.Label(window, text="Enter Name")
my_label.pack()


my_box = tk.Entry(window)
my_box.pack()

#my_button= tk.Button(window,text="Validate")
##my_button.pack()

#answer=tk.Label(window,text="")
#answer.pack()

#Phone Number Entry
my_label2 = tk.Label(window, text="Enter Phone Number")
my_label2.pack(pady=10)

my_box2 = tk.Entry(window)
my_box2.pack()
# I then added instructions for the user
instruction= tk.Label(text= "Please select your coffee below!")
instruction.pack()

#coffee list
my_coffee_list=["Light Roast","Medium Roast","Dark Roast", "Cappuccino"]
#Added coffee listbox
coffee_list= tk.Listbox(window)
coffee_list.pack()
#loop for coffee list
for item in my_coffee_list:
  coffee_list.insert(0,item)
#Loop that states the coffee you selected.
def add_coffee():
  result = ""
  for item in coffee_list.curselection():
    result = result + str(coffee_list.get(item)) + "\n"

    add_lbl.config(text="Your Coffee Selection is:" + "\n" + result)
#Made a label stating the coffee selection
add_lbl = tk.Label(window,text="")
add_lbl.pack()
# Made and add coffee button
add_button = tk.Button(window, text="Add",command=add_coffee, width=10)
add_button.pack()

#Callback functions for labels 


def check():
  text1 = my_box.get()
  
  new_lbl = tk.Label(window, text=" " + text1)
  new_lbl.pack()

  


  text3 = my_box2.get()
  
  new_lbl3 = tk.Label(window, text =" We will text  "+text3 + "" + "\n" +" when your coffee is ready.")
  new_lbl3.pack()



check_button = tk.Button(window, text = "Order Coffee", command = check)
check_button.pack()







# This function calls messagebox and lets you have dialogs for the exit button
def ExitApplication():
    MsgBox = tk.messagebox.askquestion ('Exit Application','Are you sure you want to exit the application',icon = 'warning')
    if MsgBox == 'yes':
       window.destroy()
    else:
        tk.messagebox.showinfo('Return','You will now return to the application screen')
# Button exits application and callsback to the ExitApplication function.
button = tk.Button(text = "Exit", command = ExitApplication, width=10)
button.pack()

#Logo Picture
logo_pic = ImageTk.PhotoImage(Image.open("logo.png"))
pic_lbl = tk.Label(window, image=logo_pic)
pic_lbl.pack()







tk.mainloop()